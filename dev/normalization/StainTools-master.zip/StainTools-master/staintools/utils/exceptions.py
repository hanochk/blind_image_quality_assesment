"""
Exceptions
"""


class TissueMaskException(Exception):
    pass
