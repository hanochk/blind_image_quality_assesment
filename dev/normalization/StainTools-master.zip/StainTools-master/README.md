# StainTools

Tools for tissue image stain normalization and augmentation in Python 3.

Find the README [here](https://hackmd.io/@peter554/staintools).

## Friends

If you find staintools useful you may also be interested in the awesome project [compay-syntax](https://github.com/jgamper/compay-syntax) - "making computational pathology pipelines funky, yet structured".
